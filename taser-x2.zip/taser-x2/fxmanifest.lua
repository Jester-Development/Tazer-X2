fx_version 'cerulean'
games {'gta5'}
author 'Jester-Development'

